===============================================================
 ___                            _      _            _     _
|_ _|_ __ ___  _ __   ___  _ __| |_   / \   ___ ___(_)___| |_
 | || \'_ ` _\| \'_ \ / _ \| \'__| __| / _ \ / __/ __| / __|
 | || | | | | | |_) | (_) | |  | |_ / ___ \\__ \__ \ \__ \ |_
|___|_| |_| |_| .__/ \___/|_|   \__/_/   \_\___/___/_|___/\__|
              |_|
==============================================================

 ** WHMCS ImportAssist **
Migration Tool for Hassle Free Automated Switching to WHMCS

PLEASE READ ALL THE ENCLOSED INSTRUCTIONS

Forums: http://forums.whmcs.com/
Documentation: http://docs.whmcs.com/
Client Area: http://www.whmcs.com/members/
Support: http://www.whmcs.com/get-support/

===============================================================
[ CONTENTS ]
===============================================================

1. Download
2. Installation Steps
3. Usage Instructions

===============================================================
[ DOWNLOAD ]
===============================================================

The latest version of WHMCS ImportAssist can always be obtained
from the WHMCS Marketplace at the url below.

 > https://marketplace.whmcs.com/product/46

===============================================================
[ INSTALLATION STEPS ]
===============================================================

1. Unzip the files to a folder on your computer.
2. Upload the 'import_assist' directory from the zip to the
   /modules/addons/ directory of your WHMCS installation.
3. Within the WHMCS Admin Area, navigate to Setup > Addon
   Modules.
4. Click Activate and grant your administrator role permission
   to access and use it.

==============================================================
[ USAGE INSTRUCTIONS ]
==============================================================

Once installed, you can access ImportAssist from the WHMCS
Admin Area by navigating to Addons > WHMCS ImportAssist.

For more detailed usage instructions, please refer to
http://docs.whmcs.com/ImportAssist

==============================================================

Thank you for choosing WHMCS.
